Republic of Chickens · 雞窩共和國 — v1.0

PLAY THE PREBUILT RELEASE
1. Extract the complete ZIP to a folder.
2. In that folder, run: python3 play.py
   Windows with the Python launcher: py play.py
3. Open the local address printed by the launcher in a modern browser.
4. Stop the local server with Ctrl+C.

Python 3 is required for this launcher; no Python packages or Node installation
are needed for the prebuilt game. Alternatively, serve this folder with any
ordinary static HTTP server. Opening index.html directly using file:// is not
supported because the build uses JavaScript modules.

所有內容都已包含在壓縮檔內，不需要帳號或連線至外部服務。
完整解壓縮後，在該資料夾執行 python3 play.py（Windows 可用 py play.py），
再以瀏覽器開啟終端機印出的本機位址。請勿直接雙擊 index.html。

SAVE DATA
Progress is saved in the browser on this address. Keep the same port to keep
the same browser save. Use Save & backup / 存檔與備份 to move progress between
browsers, devices, or a later hosted version. Neither language changes nor
ending choices reset the republic. Clearing browser storage erases local saves.

FIVE HALLS
Town: listen/read, resume/replay, or scroll the transcript to its end.
Mess: allocate nine finite food tokens, then serve; retries are unlimited.
Social: start a three-second preview, then find eight pairs in a 4x4 grid.
Residential: select a visible problem and complete two short repair steps.
Welfare: drag or select a patient, then choose the matching care station.

Earn 80% in each practical hall and finish the debate for five permanent checks.
The optional crossroads unlocks after all five. Neither choice ends free play.

This package is prepared for local play. It does not publish or deploy a site.
